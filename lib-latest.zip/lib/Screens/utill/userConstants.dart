class UserConstants {

  late String userLoggedIn = "userLoggedIn";
  late String userType = "userType" ;
  late String userName = "userName" ;
  late String userEmail = "userEmail" ;
  late String userId = "userId" ;
  late String timeZone = "timeZone" ;
  late String allowEmail = "allowEmail" ;
}