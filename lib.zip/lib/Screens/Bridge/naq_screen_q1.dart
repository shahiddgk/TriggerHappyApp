// ignore_for_file: avoid_print

import 'dart:convert';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter_quiz_app/Widgets/answer_field_widget.dart';
import 'package:flutter_quiz_app/Widgets/constants.dart';
import 'package:flutter_quiz_app/Widgets/question_text_widget.dart';
import 'package:flutter_quiz_app/model/request_model/response_email_request.dart';
import 'package:flutter_quiz_app/network/http_manager.dart';
import 'package:flutter_radio_button_group/flutter_radio_button_group.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../Widgets/colors.dart';
import '../../Widgets/logo_widget_for_all_screens.dart';
import '../../model/reponse_model/naq_response_model.dart';
import '../../model/reponse_model/question_answer_response_model.dart';
import '../../model/request_model/logout_user_request.dart';
import '../PireScreens/widgets/PopMenuButton.dart';
import '../Widgets/toast_message.dart';
import '../dashboard_tiles.dart';
import '../utill/userConstants.dart';
import 'naq_prev_next_button.dart';

class NaqScreen1 extends StatefulWidget {
  const NaqScreen1({Key? key}) : super(key: key);

  @override
  State<NaqScreen1> createState() => _NaqScreen1State();
}

class _NaqScreen1State extends State<NaqScreen1> {

  String name = "";
  String id = "";
  bool _isUserDataLoading = true;
  bool _isLoading = true;
  bool _isLoading2 = false;
  bool _isDataLoading = false;
  String email = "";
  String timeZone = "";
  String userType = "";

  bool isTextField = true;
  bool isYesNo = false;
  bool isOptions = false;

  String userPremium = "";
  String userPremiumType = "";
  String userCustomerId = "";
  String userSubscriptionId = "";
  String allowEmail = "";
  String errorMessage = "";
  bool isValidated = true;
  int index = 0;
  List <String> selectedItemsID = [];
  List selectedItems = [];
  Map<String, dynamic> myAnswerMap= {};

  String naqListLength = "";

  final _formKey = GlobalKey<FormState>();

  List<QuestionListResponseModel> questionListResponse = <QuestionListResponseModel>[];
  List<naq_reponse_model> naqListResponse = <naq_reponse_model>[];
  int questionListResponseLength = 0;

  final TextEditingController _fieldController = TextEditingController();

  List <String> questionOptions = [];
  // List <String> questionOptions2 = const [
  //   "Never",
  //   "Rarely",
  //   "Often",
  //   "Always",
  // ];
      int selectedItem = 0;
    String selectedString = "";
  Future<bool> _onWillPop() async {
    // if(nameController.text.isNotEmpty || descriptionController.text.isNotEmpty || purposeController.text.isNotEmpty || mentorNameController.text.isNotEmpty || mentorDescriptionController.text.isNotEmpty || peerNameController.text.isNotEmpty || peerDescriptionController.text.isNotEmpty || menteeNameController.text.isNotEmpty || menteeDescriptionController.text.isNotEmpty) {
    //   _setTrellisData();
    // }

    Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (context)=>const Dashboard()));

    return true;
  }

  @override
  void initState() {
    // TODO: implement initState
    _getQuestions();
    _getUserData();
    super.initState();
  }

  _getQuestions(){
    setState(() {
      _isLoading = true;
    });
    HTTPManager().getQuestions("naq").then((value) {
      print(value);
      // ignore: duplicate_ignore
      setState(() {

        questionListResponseLength = value.values.length;
        print("List Length");
        print(questionListResponseLength);
        //  if(value.values.isNotEmpty) {
        //  questionListResponseLength = value.values.length;
        questionListResponse = value.values;
        print(questionListResponse);
        //  } else {

        // }
        _isLoading = false;
      });
    }).catchError((e){
      print(e.toString());
      setState(() {
        questionListResponseLength == 0;
        _isLoading = false;
        errorMessage = e.toString();
      });
      showToastMessage(context, e.toString(),false);
    });
  }

  _getUserData() async {
    setState(() {
      _isUserDataLoading = true;
    });
    print("Data getting called");
    SharedPreferences sharedPreferences = await SharedPreferences.getInstance();

    name = sharedPreferences.getString(UserConstants().userName)!;
    id = sharedPreferences.getString(UserConstants().userId)!;
    email = sharedPreferences.getString(UserConstants().userEmail)!;
    timeZone = sharedPreferences.getString(UserConstants().timeZone)!;
    userType = sharedPreferences.getString(UserConstants().userType)!;
    allowEmail = sharedPreferences.getString(UserConstants().allowEmail)!;
    userPremium = sharedPreferences.getString(UserConstants().userPremium)!;
    userPremiumType = sharedPreferences.getString(UserConstants().userPremiumType)!;
    userCustomerId = sharedPreferences.getString(UserConstants().userCustomerId)!;
    userSubscriptionId = sharedPreferences.getString(UserConstants().userSubscriptionId)!;

    //_getTrellisReadData();
   // _getNAQResonseList(id);
    setState(() {
      _isUserDataLoading = false;
    });
  }

  _getNAQResonseList(String id) {
    setState(() {
      _isLoading2 = true;
    });

    HTTPManager().naqResponseList(LogoutRequestModel(userId: id)).then((value) {
      print(value);
      setState(() {
        _isLoading2 = false;
        naqListResponse = value.values;
        naqListLength = value.values.length.toString();
      });
      print("Naq list length");
      print(naqListLength);
    }).catchError((e){
      print(e);
      setState(() {
        _isLoading2 = false;
      });
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        automaticallyImplyLeading: true,
        centerTitle: true,
        leading: IconButton(
          icon: Icon(Platform.isAndroid ? Icons.arrow_back_rounded : Icons.arrow_back_ios),
          onPressed: () {
            // if(nameController.text.isNotEmpty || descriptionController.text.isNotEmpty || purposeController.text.isNotEmpty || mentorNameController.text.isNotEmpty  || peerNameController.text.isNotEmpty || menteeNameController.text.isNotEmpty ) {
            //   _setTrellisData();
            // }
            Navigator.of(context).pop();
          },
        ),
        title: Text(_isUserDataLoading ? "" : name),
        actions:  [
          PopMenuButton(false,false,id)
        ],
      ),
      body: Stack(
        children: [
          SingleChildScrollView(
            scrollDirection: Axis.vertical,
            child: Column(
              children: [
                SingleChildScrollView(
                  scrollDirection: Axis.horizontal,
                  child: Padding(
                    padding:const EdgeInsets.symmetric(horizontal: 5),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        LogoScreen("NAQ"),
                        // const SizedBox(width: 20,),
                        // IconButton(onPressed: (){
                        //   // String? videoId = YoutubePlayer.convertUrlToId(introUrl);
                        //   // YoutubePlayerController playerController = YoutubePlayerController(
                        //   //     initialVideoId: videoId!,
                        //   //     flags: const YoutubePlayerFlags(
                        //   //       autoPlay: false,
                        //   //       controlsVisibleAtStart: false,
                        //   //     )
                        //   //
                        //   // );
                        //   // videoPopupDialog(context,"Introduction to Trellis",playerController);
                        //   //bottomSheet(context,"Trellis","Welcome to Trellis, the part of the Brugeon app designed to help you flourish and live life intentionally. Trellis is a light structure that provides structure and focus, and helps propel you towards your desired outcomes. Invest at least five minutes a day in reviewing and meditating on your Trellis. If you don't have any answers yet, spend your time meditating, praying, or journaling on the questions/sections. If you have partial answers, keep taking your time daily to consider the questions and your answers. By consistently returning to your Trellis, you will become more clear and focused on creating the outcomes you desire. Enjoy your Trellis!","");
                        // }, icon: const Icon(Icons.ondemand_video,size:30,color: AppColors.infoIconColor,)),
                        // const SizedBox(height: 5,),

                      ],
                    ),
                  ),
                ),
                const Divider(color: AppColors.primaryColor,
                thickness: 1,
                ),
               _isLoading ? const CircularProgressIndicator() : questionListResponse.isEmpty ? QuestionTextWidget("", "urlText", (){}, false)  : Column(
                  children: [
                    QuestionTextWidget("Step # ${index+1} / ${questionListResponse.length}", "urlText", (){}, false),
                    index+1 == questionListResponse.length ?
                    QuestionTextWidget(questionListResponse[index-1].title, "urlText", (){}, false)
                    : QuestionTextWidget(questionListResponse[index].title, "urlText", (){}, false),

                    Visibility(
                      visible: questionListResponse[index].responseType == "radio_btn",
                      child: Container(
                        padding:const EdgeInsets.symmetric(horizontal: 10),
                        child: ListView.builder(
                            shrinkWrap: true,
                            itemCount: questionListResponse[index].options.length,
                            itemBuilder: (context,index1) {
                              return RadioListTile<int>(
                              title: Text(questionListResponse[index].options[index1]),
                              value: index1,
                              groupValue: selectedItem,
                              onChanged: (value) {
                                print(value);
                                print(questionListResponse[index].options[index1]);
                              setState(() {
                              selectedItem = value!;
                              selectedString = questionListResponse[index].options[index1];
                              });
                            });

                        // FlutterRadioButtonGroup(
                        //     activeColor: AppColors.primaryColor,
                        //     checkIconColor: AppColors.primaryColor,
                        //     distanceToNextItem: 15,
                        //     distanceToCheckBox: 15,
                        //     textStyle:const TextStyle(fontWeight: FontWeight.bold,fontSize: AppConstants.defaultFontSize),
                        //     items: questionListResponse[index].options.map((item) => item as String).toList(),
                        //     initialSelection: selectedItem,
                        //     onSelected: (String selected) {
                        //     //  print("Selected: $selected");
                        //     setState(() {
                        //       selectedString = selected;
                        //     });
                             }),
                      ),
                    ),

                    Visibility(
                      visible: questionListResponse[index].responseType == "open_text",
                      child: Container(
                          padding:const EdgeInsets.symmetric(horizontal: 10),
                          child: Container(
                            decoration: BoxDecoration(
                              color: AppColors.naqFieldColor,
                              borderRadius: BorderRadius.circular(5),
                            ),
                            child: TextFormField(
                              autofocus: true,
                              controller: _fieldController,
                              textInputAction: TextInputAction.done,
                              style: const TextStyle(fontSize: AppConstants.defaultFontSize),
                              decoration:const InputDecoration(
                                hintText: "write something here",
                                  contentPadding: EdgeInsets.symmetric(horizontal: 10,vertical: 10),
                                  border: InputBorder.none
                              ),
                              validator: (value) {
                                if(value!.trim().isEmpty) {
                                  setState(() {
                                    errorMessage = "write something here ";
                                    isValidated = true;
                                  });
                                  return "";
                                } else {
                                  setState(() {
                                    errorMessage = "";
                                    isValidated = false;
                                  });
                                  return null;
                                }
                              },
                              maxLines: 5,
                            ),
                          )
                      ),
                    ),
                    const SizedBox(
                      height: 20,
                    ),
                    const Divider(color: AppColors.primaryColor,
                      thickness: 1,
                    ),
                    naqPrevNextButton((){

                      setState(() {
                        if(index != 0) {
                          removeAnswerFromLocal();
                          index = index - 1;

                        }
                        // isTextField = false;
                        // isYesNo = true;
                        // isOptions = false;
                      });
                      print("Previous pressed!");
                      print(index);
                    },(){
                      if(questionListResponse[index].responseType == "open_text" && _fieldController.text.isEmpty) {
                        showToastMessage(context, "Write something here", false);
                      } else {
                        setState(() {
                            if (questionListResponse[index].responseType ==
                                "open_text") {
                              selectedString = _fieldController.text.toString();
                            } else {
                              selectedString = questionListResponse[index].options[selectedItem];
                            }
                            saveAnswerOnLocal(
                                questionListResponse[index].id.toString(),
                                questionListResponse[index].responseType
                                    .toString(), selectedString,false);

                            index = index + 1;
                          // isTextField = false;
                          // isYesNo = false;
                          // isOptions = true;
                        });
                        print("Next pressed!");
                        print(index);
                        print(questionListResponse.length);
                      }
                    },index == 0 ? false : true, index+1 == questionListResponse.length ? false : true),

                    Visibility(
                        visible: index+1 == questionListResponse.length,
                        child: ElevatedButton(
                            onPressed: (){
                              if(questionListResponse[index].responseType == "open_text" && _fieldController.text.isEmpty) {
                                showToastMessage(context, "Write something here", false);
                              } else {
                                setState(() {
                                  if (questionListResponse[index].responseType ==
                                      "open_text") {
                                    selectedString = _fieldController.text.toString();
                                  } else {
                                    selectedString = questionListResponse[index].options[selectedItem];
                                  }
                                  saveAnswerOnLocal(
                                      questionListResponse[index].id.toString(),
                                      questionListResponse[index].responseType
                                          .toString(), selectedString,true);

                                  //index = index + 1;
                                  // isTextField = false;
                                  // isYesNo = false;
                                  // isOptions = true;
                                });
                                print("Next pressed!");
                                print(index);
                                print(questionListResponse.length);
                              }
                            },
                          style: ElevatedButton.styleFrom(
                            minimumSize: Size(MediaQuery.of(context).size.width/2, 40), // Set the minimum width and height
                            padding: EdgeInsets.zero, // Remove any default padding
                          ),
                            child:const Text("Submit",style: TextStyle(color: AppColors.backgroundColor),),
                        ))
                  ],
                )


                // Visibility(
                //   visible: isOptions,
                //   child: Container(
                //     padding:const EdgeInsets.symmetric(horizontal: 10),
                //     child: FlutterRadioButtonGroup(
                //         activeColor: AppColors.primaryColor,
                //         checkIconColor: AppColors.primaryColor,
                //         distanceToNextItem: 15,
                //         distanceToCheckBox: 15,
                //         textStyle:const TextStyle(fontWeight: FontWeight.bold,fontSize: AppConstants.defaultFontSize),
                //         items: questionOptions2,
                //         initialSelection: selectedItem,
                //         onSelected: (String selected) {
                //           print("Selected: $selected");
                //         }),
                //   ),
                // ),


              ],
            ),
          ),
          _isDataLoading ?
          const Center(child: CircularProgressIndicator())
              : Container() ,
        ],
      ),
    );
  }
  setMapForApi() {
    setState(() {
      selectedItem = 0;
      print(selectedItem);
      _fieldController.text == "";
      _fieldController.clear();
      selectedString == "";
    });
    for (int i = 0; i < selectedItemsID.length; i++) {
      myAnswerMap[selectedItemsID[i]] = selectedItems[i];
    }
    print("All Answers Of NAQ");
    // print(selectedItems);
    print(selectedItemsID);
    print(selectedItems.length);
    print(myAnswerMap);
    if(myAnswerMap.isNotEmpty) {
      final String encodedData = jsonEncode(myAnswerMap);
     // Navigator.of(context).pop();
      setState(() {
        _isDataLoading = true;
      });
      HTTPManager().userResponseEmail(UserResponseRequestModel(name: name, email: email, userId: id, answerMap: encodedData,type: "naq")).then((value) {

        print(value);
        if(allowEmail == "yes") {
          showToastMessage(context, value['message'].toString(), true);
        }
        Navigator.of(context).pop();
        setState(() {
          _isDataLoading = false;
        });
      }).catchError((e) {
        print(e);
        showToastMessage(context, e.toString(), false);
        setState(() {
          _isDataLoading = false;
        });
      });
     // Navigator.of(context).pushAndRemoveUntil(MaterialPageRoute(builder: (context)=>const Dashboard()), (route) => false);
    }
  }

  saveAnswerOnLocal(String questionId,String responseType,String questionTitle,bool isDataUpload) {
    setState(() {
      selectedItem = 0;
      print(selectedItem);
      _fieldController.text == "";
       _fieldController.clear();
      selectedString == "";
    });
    dynamic answerText = { "type": responseType, "answer": [questionTitle]};

   // answerTextList.add(answerText);


    selectedItemsID.add(questionId);
    selectedItems.add(answerText);
    print("Any Option addition to list");
   // print(answerTextList);
    print(selectedItems);
    if(isDataUpload) {
      setMapForApi();
    }
  }

  removeAnswerFromLocal() {
    selectedItemsID.removeAt(selectedItemsID.length-1);
    selectedItems.removeAt(selectedItems.length-1);
}
}
