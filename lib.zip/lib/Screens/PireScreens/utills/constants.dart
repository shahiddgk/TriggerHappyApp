class PireConstants {

  static String questionOneId = "questionId1";
  static String questionOneType = "answerType1";
  static String questionOneText = "answerText1";

  static String questionTwoId = "questionId2";
  static String questionTwoType = "answerType2";
  static String questionTwoText = "answerText2";

  static String questionThreeId = "questionId3";
  static String questionThreeType = "answerType3";
  static String questionThreeText = "answerText3";

  static String questionFourId = "questionId4";
  static String questionFourType = "answerType4";
  static String questionFourText = "answerText4";

  static String questionFiveId = "questionId5";
  static String questionFiveType = "answerType5";
  static String questionFiveText = "answerText5";

  static String questionSixId = "questionId6";
  static String questionSixType = "answerType6";
  static String questionSixText = "answerText6";

  static String questionSevenId = "questionId7";
  static String questionSevenType = "answerType7";
  static String questionSevenText = "answerText7";

  static String questionEightId = "questionId8";
  static String questionEightType = "answerType8";
  static String questionEightText = "answerText8";

  static String questionNineId = "questionId9";
  static String questionNineType = "answerType9";
  static String questionNineText = "answerText9";

  static String questionTenId = "questionId10";
  static String questionTenType = "answerType10";
  static String questionTenText = "answerText10";

  static String questionElevenId = "questionId11";
  static String questionElevenType = "answerType11";
  static String questionElevenText = "answerText11";

}