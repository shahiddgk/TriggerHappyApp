class AppConstants {
  static const double headingFontSize = 20;
  static const double headingFontSizeForCreation = 26;
  static const double headingFontSizeForEntriesAndSession = 20;
  static const double defaultFontSize = 12;
  static const double columnDetailsScreenFontSize = 16;
  static const double logoFontSizeForIpad = 33;
  static const double logoFontSizeForMobile = 28.69;
}