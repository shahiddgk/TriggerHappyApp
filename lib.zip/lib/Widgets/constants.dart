class AppConstants {

  static const double defaultFontSize = 14;

}